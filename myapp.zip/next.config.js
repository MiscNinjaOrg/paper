/** @type {import('next').NextConfig} */
const nextConfig = {
    experimental: {
        outputStandalone: true,
    },
}

module.exports = nextConfig
