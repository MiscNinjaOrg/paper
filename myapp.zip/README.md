## Run via Docker

Detailed instructions on building coming soon.

For now, just use the image from Docker Hub

```
docker pull lordspline/miscninja-paper
docker run -d -p 80:80 lordspline/miscninja-paper
```

Then go to `http://localhost/` in your browser.

Remember to provide your OpenAI API Key.
